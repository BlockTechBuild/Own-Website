<?php

namespace Presenters;

/**
 * Interpersonal Presenter Class which contains the interpersonal skill transfer information.
 */

class Interpersonal extends BaseDTO
{
    /* CONSTRUCTOR */

    public function __construct($poInterpersonal)
    {
        parent::__construct($poInterpersonal);
    }
}